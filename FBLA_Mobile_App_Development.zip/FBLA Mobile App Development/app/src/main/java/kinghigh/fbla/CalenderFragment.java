package kinghigh.fbla;

import android.content.Context;
import android.graphics.Color;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.github.sundeepk.compactcalendarview.CompactCalendarView;
import com.github.sundeepk.compactcalendarview.domain.Event;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;


public class CalenderFragment extends Fragment {

    public CalenderFragment()
    {
    }
    ListView listView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_calender, container, false);
        final ActionBar actionBar = ((AppCompatActivity)getActivity()).getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(false);
        actionBar.setTitle(null);


        listView=(ListView)view.findViewById(R.id.listview);

        ArrayList<String> arrayList= new ArrayList<>();
        arrayList.add("                                           2019");
        arrayList.add("July 18-19                   FBLA-PBL Advisers’ Training, Wesley Chapel");
        arrayList.add("July 19-20                   FBLA-PBL District Director Summit, Wesley Chapel\n");
        arrayList.add("July 20-21                   FBLA-PBL Board of Directors Meeting, Wesley Chapel");
        arrayList.add("September 30             Receipt deadline for articles for the fall issue of Florida Communicator");
        arrayList.add("October 7                      Receipt deadline for State Fall Conference Registration");
        arrayList.add("October 20                   State and national initial dues deadline, to be eligible for Gold Seal Award");
        arrayList.add("November 8-10            State Fall Leadership Conference, Championsgate");
        arrayList.add("November 9                 Board of Directors Meeting");
        arrayList.add("November 15               American Enterprise Day");
        arrayList.add("November 15               FBLA District Directors must have district test orders to State Adviser if Competition is in December");
        arrayList.add("November 30               Receipt deadline for articles for the winter issue of Florida Communicator");
        arrayList.add("December 4                 FBLA District Directors must have district test orders to State Adviser if competition is in January or February");
        arrayList.add("December 15               FBLA state and national dues must be postmarked, first-class mail, to be eligible for district, state, and national competition");
        arrayList.add("                                          2020");
        arrayList.add("January 1                     Deadline for receipt of intent letters/resumes to run for national office");
        arrayList.add("January 25-26              FBLA-PBL Board of Directors Meeting, TBA");
        arrayList.add("January 30                   Receipt deadline for articles for the spring issue of Florida Communicator");
        arrayList.add("February 2-4                Tallahassee Trip for State FBLA and PBL Officers ");
        arrayList.add("February 2-8                FBLA/PBL WEEK ");
        arrayList.add("February 12                 FBLA received date for State Conference registration/hotel reservations/pre-judged materials");
        arrayList.add("February 15                 PBL State/National dues postmark deadline to be eligible for State Competition");
        arrayList.add("February 15                 PBL received date for State Conference registration/hotel reservations/ pre-judged materials");
        arrayList.add("March 12-15                FBLA State Leadership Conference, Hilton Orlando, Orlando");
        arrayList.add("March 26-29                PBL Sate Leadership Conference, Doubletree SeaWorld, Orlando");
        arrayList.add("April 25 & May 9        FBLA-PBL Pre-NLCs, TBA");
        arrayList.add("June 24-27                   PBL National Leadership Conference, Salt Lake City, UT");
        arrayList.add("June 29-July 2             FBLA National Leadership Conference, Salt Lake City, UT");

        ArrayAdapter arrayAdapter = new ArrayAdapter(getContext(),android.R.layout.simple_list_item_1,arrayList);
        listView.setAdapter(arrayAdapter);




        CompactCalendarView compactCalendar = (CompactCalendarView) view.findViewById(R.id.compactcalendar_view);
        compactCalendar.setUseThreeLetterAbbreviation(true);



        final Date event1Date = createDate(10, Calendar.JANUARY, 2020);
        final Date event2Date = createDate(14, Calendar.JANUARY, 2020);
        Date event3Date = createDate(17, Calendar.JANUARY, 2020);
        Date event4Date = createDate(30, Calendar.JANUARY, 2020);
        Date event5Date = createDate(12, Calendar.MARCH, 2020);
        Date event6Date = createDate(13, Calendar.MARCH, 2020);
        Date event7Date = createDate(14, Calendar.MARCH, 2020);
        Date event8Date = createDate(15, Calendar.MARCH, 2020);
        Date event9Date = createDate(29, Calendar.JUNE, 2020);
        Date event10Date = createDate(30, Calendar.JUNE, 2020);
        Date event11Date = createDate(1, Calendar.JULY, 2020);
        Date event12Date = createDate(2, Calendar.JULY, 2020);

        final Event ev1 = new Event(Color.WHITE, event1Date.getTime(), "Event Testing");
        compactCalendar.addEvent(ev1);
        final Event ev2 = new Event(Color.WHITE, event2Date.getTime(), "Performance Event Judgement Day");
        compactCalendar.addEvent(ev2);
        Event ev3 = new Event(Color.WHITE, event3Date.getTime(), "Submission Events Due");
        compactCalendar.addEvent(ev3);
        Event ev4 = new Event(Color.WHITE, event4Date.getTime(), "Event Testing");
        compactCalendar.addEvent(ev4);
        Event ev5 = new Event(Color.WHITE, event5Date.getTime(), "Event Testing");
        compactCalendar.addEvent(ev5);
        Event ev6 = new Event(Color.WHITE, event6Date.getTime(), "Event Testing");
        compactCalendar.addEvent(ev6);
        Event ev7 = new Event(Color.WHITE, event7Date.getTime(), "Event Testing");
        compactCalendar.addEvent(ev7);
        Event ev8 = new Event(Color.WHITE, event8Date.getTime(), "Event Testing");
        compactCalendar.addEvent(ev8);
        Event ev9 = new Event(Color.WHITE, event9Date.getTime(), "Event Testing");
        compactCalendar.addEvent(ev9);
        Event ev10 = new Event(Color.WHITE, event10Date.getTime(), "Event Testing");
        compactCalendar.addEvent(ev10);
        Event ev11 = new Event(Color.WHITE, event11Date.getTime(), "Event Testing");
        compactCalendar.addEvent(ev11);
        Event ev12 = new Event(Color.WHITE, event12Date.getTime(), "Event Testing");
        compactCalendar.addEvent(ev12);



        compactCalendar.setListener(new CompactCalendarView.CompactCalendarViewListener() {
            @Override
            public void onDayClick(Date dateClicked) {
                Context context = getContext();

                SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

                String formattedDate = formatter.format(dateClicked);
                if (formattedDate.compareTo("01/10/2020")==0) {
                    Toast.makeText(context, "Event Testing", Toast.LENGTH_SHORT).show();
                }
                else if (formattedDate.compareTo("01/14/2020")==0) {
                    Toast.makeText(context, "Performance Event Judgement Day", Toast.LENGTH_SHORT).show();
                }
                else if (formattedDate.compareTo("01/17/2020") == 0) {
                    Toast.makeText(context, "Submission Events Due", Toast.LENGTH_SHORT).show();
                }
                else if (formattedDate.compareTo("01/30/2020")==0){
                    Toast.makeText(context, "District Awards",Toast.LENGTH_SHORT).show();
                }
                else if (formattedDate.compareTo("03/12/2020")==0){
                    Toast.makeText(context, "State Competition",Toast.LENGTH_SHORT).show();
                }
                else if (formattedDate.compareTo("03/13/2020")==0){
                    Toast.makeText(context, "State Performance Judgement Day",Toast.LENGTH_SHORT).show();
                }
                else if (formattedDate.compareTo("03/14/2020")==0){
                    Toast.makeText(context, "State Testing Day",Toast.LENGTH_SHORT).show();
                }
                else if (formattedDate.compareTo("03/15/2020")==0){
                    Toast.makeText(context, "State Competition",Toast.LENGTH_SHORT).show();
                }
                else if (formattedDate.compareTo("06/29/2020")==0){
                    Toast.makeText(context, "National Competition",Toast.LENGTH_SHORT).show();
                }
                else if (formattedDate.compareTo("06/30/2020")==0){
                    Toast.makeText(context, "National Competition",Toast.LENGTH_SHORT).show();
                }
                else if (formattedDate.compareTo("07/01/2020")==0){
                    Toast.makeText(context, "National Competition",Toast.LENGTH_SHORT).show();
                }
                else if (formattedDate.compareTo("07/02/2020")==0){
                    Toast.makeText(context, "National Competition",Toast.LENGTH_SHORT).show();
                }

                else {
                    Toast.makeText(context, "No Events Planned for that day", Toast.LENGTH_SHORT).show();
                }


            }

            @Override
            public void onMonthScroll(Date firstDayOfNewMonth) {
                SimpleDateFormat dateFormatMonth = new SimpleDateFormat("MMM YYYY");
                actionBar.setTitle(dateFormatMonth.format(firstDayOfNewMonth));
            }
        });

        return view;
    }

    private Date createDate(int dayOfMonth, int month, int year)
    {
        Calendar eventDate = Calendar.getInstance();
        eventDate.set(Calendar.YEAR, year);
        eventDate.set(Calendar.MONTH,  month);
        eventDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);

        return eventDate.getTime();
    }
}
