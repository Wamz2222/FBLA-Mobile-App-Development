package kinghigh.fbla;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class EventsFragment extends Fragment implements View.OnClickListener {


    public EventsFragment() {
    }

    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_events, container, false);

        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("KHS FBLA");

        Button EFButton = view.findViewById(R.id.btnevent);
        EFButton.setOnClickListener(this);
        return view;

    }

    @Override
    public void onClick(View v) {
        Intent eventIntent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://forms.gle/RotwhF3hjKiBbBqR9"));
        startActivity(eventIntent);
        }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TextView textView = (TextView) getView().findViewById(R.id.eventslink);

        String text = "For more detailed information about the events, visit https://www.fbla-pbl.org/fbla/competitive-events/";

        SpannableString ss = new SpannableString(text);

        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                Intent browerIntent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.fbla-pbl.org/fbla/competitive-events/"));
                startActivity(browerIntent);
        //Submissions are sent to https://docs.google.com/spreadsheets/d/1ZYABOClZJmDhf0C4jdS7maPUDQpFOJgoxaCV9fsINeM/edit?usp=forms_web_b#gid=701987626
            }
        };

        ss.setSpan(clickableSpan, 54, 103, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        textView.setText(ss);
        textView.setMovementMethod(LinkMovementMethod.getInstance());

    }

}
