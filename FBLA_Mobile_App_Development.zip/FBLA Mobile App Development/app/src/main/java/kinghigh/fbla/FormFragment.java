package kinghigh.fbla;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class FormFragment extends Fragment implements View.OnClickListener {


    public FormFragment() {
    }

    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_form, container, false);

        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("KHS FBLA");

        Button JoinButton = view.findViewById(R.id.btnjoin);
        JoinButton.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        Intent joinIntent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://forms.gle/2p6S9LZ5yCfbQAQVA"));
        startActivity(joinIntent);
//      Submissions are sent to https://docs.google.com/spreadsheets/d/1BzgS9fORcaRz3FRow95609XdmEOL_RQ6VLBpDIMSisw/edit?usp=sharing
    }
}
